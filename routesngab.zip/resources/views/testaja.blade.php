@extends('layouts.main')

@include('partials.navbar')

@section('container')
    <div class="container mt-4">
        <h1>Halaman Home</h1>
    </div>
@endsection