<!-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>

<style>
    body {
        background-color: pink;
    }
</style>

<body>
    <h3>Home</h3>
    <a href="/about">About</a>
    <h4>Belajar Workshop Sistem Informasi Web Framework - Laravel</h4>

</body>

</html> -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset='UTF-8' />
    <meta content='width=device-width, initial-scale=1, user-scalable=1, minimum-scale=1, maximum-scale=5'
        name='viewport' />
    <meta content='IE=edge' http-equiv='X-UA-Compatible' />
    <title>Jurusan Teknologi Informasi</title>
    <link rel="icon" type="image/png" sizes="16x16" href="http://103.109.209.245/jtiform/assets/img/favicon.png" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta content="Kuisioner Jurusan Teknologi Informasi" name="description" />
    <meta content="Politeknik Negeri Jember" name="author" />
    <link rel="stylesheet" href="css/home-css.css">
</head>


<body class="background">
    <div class="row vh-100">
        <div class="col-lg-9 p-0">
            <div class="accountbg">
                <div class="account-title">
                    <img src="http://103.109.209.245/jtiform/assets/img/favicon.png" alt="" class="thumb-sm" />
                    <h4 class="mt-3">Welcome To JTI Polije</h4>
                    <div class="border w-25 mx-auto border-primary"></div>
                    <h1 class="marquee">
                        <marquee scrollamount="15">TETAP SEMANGAT NUGAS WALAUPUN GA DISEMANGATIN AYAANG</marquee>
                    </h1>
                    <p class="font-14 mt-3">
                        #PolijeSIP #JTIPolije #TIPC
                        <a href="/testaja" class="font-14 mt-3">#ez</a>
                    </p>
                </div>
            </div>
        </div>
    </div>


</body>

</html>
